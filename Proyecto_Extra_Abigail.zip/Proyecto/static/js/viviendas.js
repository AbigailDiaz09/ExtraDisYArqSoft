let municipio = (selectElement) => {
    var selectedValue = selectElement.value;
    data={
        'id': selectedValue
    }
    fetch('/lista-localidades', {
        method:"POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then (response => response.json())
    .then (data => {
        select = document.getElementById('localidades_idlocalidades');
        select.textContent = "";
        option = document.createElement('option');
        option.textContent = "Seleccione una localidad";
        select.appendChild(option);
        data.forEach(function(localidad){
            option = document.createElement('option');
            option.value = localidad.idlocalidades;
            option.textContent = localidad.nombre_localidad;
            select.appendChild(option)
        });
    })
    .catch(error => console.log(error))
}