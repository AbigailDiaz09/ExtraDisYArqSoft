from model.conexion import BD

class Habitante:
    def __init__(self, idhabitante, nombre, edad, sexo, edo_civil, nivel_educativo, ingresos, nacionalidad, vivienda_idvivienda):
        self.idhabitante = idhabitante
        self.nombre = nombre
        self.edad = edad
        self.sexo = sexo
        self.edo_civil = edo_civil
        self.nivel_educativo = nivel_educativo
        self.ingresos = ingresos
        self.nacionalidad = nacionalidad
        self.vivienda_idvivienda = vivienda_idvivienda

    @classmethod
    def buscar(cls, idhabitante):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM habitante WHERE idhabitante = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (idhabitante,))
                result = cursor.fetchone()
                if result:
                    habitante = cls(result[0], result[1], result[2], result[3], result[4], result[5], result[6], result[7], result[8])
                    return habitante
                else:
                    return None
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def listar(cls, idVivienda):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM habitante WHERE vivienda_idvivienda = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (idVivienda,))
                results = cursor.fetchall()
                habitantes = []
                for result in results:
                    habitante = cls(result[0], result[1], result[2], result[3], result[4], result[5], result[6], result[7], result[8])
                    habitantes.append(habitante)
                return habitantes
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    def crear(self):
        bd = BD()
        bd.connect()
        consulta_max_id = "SELECT MAX(idhabitante) FROM habitante"
        consulta = "INSERT INTO habitante (idhabitante, nombre, edad, sexo, edo_civil, nivel_educativo, ingresos, nacionalidad, vivienda_idvivienda) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta_max_id)
                max_id = cursor.fetchone()[0]
                if max_id is None:
                    max_id = 0
                nuevo_id = max_id + 1
                cursor.execute(consulta, (nuevo_id, self.nombre, self.edad, self.sexo, self.edo_civil, self.nivel_educativo, self.ingresos, self.nacionalidad, self.vivienda_idvivienda))
                bd.conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def eliminar(cls, idhabitante):
        bd = BD()
        bd.connect()
        consulta = "DELETE FROM habitante WHERE idhabitante = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (idhabitante,))
                bd.conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()