from model.conexion import BD

class Ocupacion:
    def __init__(self, idocupacion, nombre_ocupacion):
        self.idocupacion = idocupacion
        self.nombre_ocupacion = nombre_ocupacion
    
    @classmethod
    def listar(cls):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM ocupacion"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta,)
                results = cursor.fetchall()
                ocupaciones = []
                for result in results:
                    ocupacion = cls(result[0], result[1])
                    ocupaciones.append(ocupacion)
                return ocupaciones
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()