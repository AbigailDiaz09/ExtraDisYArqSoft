from model.conexion import BD

class Vivienda:
    def __init__(self, idvivienda, tipo_vivienda, material, saneamiento, agua, luz, drenaje, tendencia, direccion, num_habitaciones, num_banios, localidades_idlocalidades, localidades_municipio_idmunicipio):
        self.idvivienda = idvivienda
        self.tipo_vivienda = tipo_vivienda
        self.material = material
        self.saneamiento = saneamiento
        self.agua = agua
        self.luz = luz
        self.drenaje = drenaje
        self.tendencia = tendencia
        self.direccion = direccion
        self.num_habitaciones = num_habitaciones
        self.num_banios = num_banios
        self.localidades_idlocalidades = localidades_idlocalidades
        self.localidades_municipio_idmunicipio = localidades_municipio_idmunicipio

    @classmethod
    def buscar(cls, idvivienda):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM vivienda WHERE idvivienda = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (idvivienda,))
                result = cursor.fetchone()
                if result:
                    vivienda = cls(result[0], result[1], result[2], result[3], result[4], result[5], result[6], result[7], result[8], result[9], result[10], result[11], result[12])
                    return vivienda
                else:
                    return None
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def listar(cls):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM vivienda"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta)
                results = cursor.fetchall()
                viviendas = []
                for result in results:
                    vivienda = cls(result[0], result[1], result[2], result[3], result[4], result[5], result[6], result[7], result[8], result[9], result[10], result[11], result[12])
                    viviendas.append(vivienda)
                return viviendas
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    def crear(self):
        bd = BD()
        bd.connect()
        consulta = "INSERT INTO vivienda (tipo_vivienda, material, saneamiento, agua, luz, drenaje, tendencia, direccion, num_habitaciones, num_banios, localidades_idlocalidades, localidades_municipio_idmunicipio) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (self.tipo_vivienda, self.material, self.saneamiento, self.agua, self.luz, self.drenaje, self.tendencia, self.direccion, self.num_habitaciones, self.num_banios, self.localidades_idlocalidades, self.localidades_municipio_idmunicipio))
                bd.conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def eliminar(cls, id):
        bd = BD()
        bd.connect()
        consulta = "DELETE FROM vivienda WHERE idvivienda = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (id))
                bd.conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()
    
    def NumHabitantes():
        bd = BD()
        bd.connect()
        consulta = "SELECT (SELECT COUNT(*) FROM habitante WHERE vivienda_idvivienda = v.idvivienda) as habitantes FROM vivienda v"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta)
                results = cursor.fetchall()
                habitantes = []
                for result in results:
                    habitantes.append(result[0])
                return habitantes
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def NumHabitantesId(cls, idLocalidad):
        bd = BD()
        bd.connect()
        consulta = '''SELECT
    v.idvivienda,
    v.direccion AS direccion_vivienda,
    COUNT(h.idhabitante) AS num_habitantes
FROM
    vivienda v
LEFT JOIN
    habitante h ON v.idvivienda = h.vivienda_idvivienda
WHERE
    v.localidades_idlocalidades = %s
GROUP BY
    v.idvivienda, v.direccion
'''
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (idLocalidad))
                results = cursor.fetchall()
                habitantes = []
                for result in results:
                    fila = {'id': result[0], 'vivienda':result[1],'habitantes': result[2]}
                    habitantes.append(fila)
                return habitantes
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()