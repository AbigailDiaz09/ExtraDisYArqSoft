from model.conexion import BD

class Municipio:
    def __init__(self, idmunicipio, nombre_municipio):
        self.idmunicipio = idmunicipio
        self.nombre_municipio = nombre_municipio

    @classmethod
    def buscar(cls, idmunicipio):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM municipio WHERE idmunicipio = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (idmunicipio,))
                result = cursor.fetchone()
                if result:
                    municipio = cls(result[0], result[1])
                    return municipio
                else:
                    return None
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def listar(cls):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM municipio"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta)
                results = cursor.fetchall()
                municipios = []
                for result in results:
                    municipio = cls(result[0], result[1])
                    municipios.append(municipio)
                return municipios
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def numHabitantes(cls):
        bd = BD()
        bd.connect()
        consulta = '''SELECT
    m.idmunicipio,
    m.nombre_municipio,
    COUNT(h.idhabitante) AS num_habitantes
FROM
    municipio m
LEFT JOIN
    localidades l ON m.idmunicipio = l.municipio_idmunicipio
LEFT JOIN
    vivienda v ON l.idlocalidades = v.localidades_idlocalidades
LEFT JOIN
    habitante h ON v.idvivienda = h.vivienda_idvivienda
GROUP BY
    m.idmunicipio, m.nombre_municipio'''
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta)
                results = cursor.fetchall()
                habitantes = []
                for result in results:
                    fila = {'id': result[0], 'municipio':result[1],'habitantes': result[2]}
                    habitantes.append(fila)
                return habitantes
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()