from model.conexion import BD

class Localidad:
    def __init__(self, idlocalidades, nombre_localidad, ambito, municipio_idmunicipio):
        self.idlocalidades = idlocalidades
        self.nombre_localidad = nombre_localidad
        self.ambito = ambito
        self.municipio_idmunicipio = municipio_idmunicipio

    @classmethod
    def buscar(cls, idlocalidades):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM localidades WHERE idlocalidades = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (idlocalidades,))
                result = cursor.fetchone()
                if result:
                    localidad = cls(result[0], result[1], result[2], result[3])
                    return localidad
                else:
                    return None
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def listar_por_municipio(cls, municipio_idmunicipio):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM localidades WHERE municipio_idmunicipio = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (municipio_idmunicipio,))
                results = cursor.fetchall()
                localidades = []
                for result in results:
                    localidad = cls(result[0], result[1], result[2], result[3])
                    localidades.append(localidad)
                return localidades
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()

    @classmethod
    def NumHabitantes(cls, idMunicipio):
        bd = BD()
        bd.connect()
        consulta = '''SELECT
    l.idlocalidades,
    l.nombre_localidad,
    COUNT(h.idhabitante) AS num_habitantes
FROM
    localidades l
LEFT JOIN
    vivienda v ON l.idlocalidades = v.localidades_idlocalidades
LEFT JOIN
    habitante h ON v.idvivienda = h.vivienda_idvivienda
WHERE
    l.municipio_idmunicipio = %s
GROUP BY
    l.idlocalidades, l.nombre_localidad
'''
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (idMunicipio))
                results = cursor.fetchall()
                habitantes = []
                for result in results:
                    fila = {'id': result[0], 'localidad':result[1],'habitantes': result[2]}
                    habitantes.append(fila)
                return habitantes
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()