from model.conexion import BD
class Usuario:
    def __init__(self, id, usuario, password):
        self.id = id
        self.usuario = usuario
        self.password = password
    
    @classmethod
    def buscar(cls, usuario):
        bd = BD()
        bd.connect()
        consulta = "SELECT * FROM login_usuario WHERE usuario = %s"
        try:
            with bd.cursor as cursor:
                cursor.execute(consulta, (usuario,))
                result = cursor.fetchone()
                if result:
                    usuario = cls(result[0], result[1], result[2])
                    return usuario
                else:
                    return None
        except Exception as e:
            print(e)
        finally:
            bd.conn.close()