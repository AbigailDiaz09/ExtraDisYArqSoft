import pymysql

class BD:
    _instancia = None
    conn = ""
    cursor = ""
    def __new__(cls):
        if cls._instancia is None:
            cls._instancia = super(BD, cls).__new__(cls)
        return cls._instancia

    def connect(self):
        try:
            self.conn=pymysql.connect(host='localhost',
                                    port=3306,
                                    user='root',
                                    password='AbigailDiaz19/',
                                    db='censopoblacion'
                                    )
            self.cursor=self.conn.cursor()
        except  Exception as e:
            print(e)

    def close(self):
        try:
            self.cursor.close()
            self.conn.close()
        except Exception as e:
            print(e)
