from flask import Flask, render_template, url_for, redirect, session, request, jsonify
from flask_session import Session
import plotly.express as px
import plotly
import pandas as pd
import json
from model.usuario  import Usuario
from model.viviendas import Vivienda
from model.municipio import Municipio
from model.localidad import Localidad
from model.habitante import Habitante

app = Flask(__name__)
app.config['SECRET_KEY'] = 'Una llave'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['post'])
def login():
    usuario = request.form.get('usuario')
    password = request.form.get('password')
    user = Usuario.buscar(usuario)
    if user is not None:
        if str(user.password) == "b'"+str(password)+"'":
            return redirect(url_for('admin'))
        else:
            return '''<script>
                alert("contraseña incorrecta");
                window.location.href="/";
            </script>'''
    else:
        return '''<script>
                alert("usuario incorrecta");
                window.location.href="/";
            </script>'''
    
@app.route('/viviendas')
def viviendas():
    municipios = Municipio.listar()
    return render_template('viviendas.html', municipios = municipios)

@app.route('/lista-viviendas')
def listaViviendas():
    viviendas = Vivienda.listar()
    return render_template('listaViviendas.html', viviendas = viviendas)
    
@app.route('/lista-localidades', methods=['post'])
def listaLocalidades():
    localidades = Localidad.listar_por_municipio(request.get_json()['id'])
    localidadesJson = []
    for localidad in localidades:
        localidadesJson.append({
            'idlocalidades': localidad.idlocalidades,
            'nombre_localidad': localidad.nombre_localidad,
            'ambito': localidad.ambito,
            'municipio_idmunicipio': localidad.municipio_idmunicipio
        })
    return jsonify(localidadesJson)

@app.route('/guardar-vivienda', methods = ['post'])
def guardarVivienda():
    tipo = request.form.get('tipo_vivienda')
    material = request.form.get('material')
    saneamiento = request.form.get('saneamiento')
    agua = request.form.get('agua')
    luz = request.form.get('luz')
    drenaje = request.form.get('drenaje')
    tendencia = request.form.get('tendencia')
    direccion = request.form.get('direccion')
    habitaciones = request.form.get('num_habitaciones')
    banios = request.form.get('num_banios')
    municipio = request.form.get('localidades_municipio_idmunicipio')
    localidades = request.form.get('localidades_idlocalidades')

    agua = 'si' if agua == 'on' else 'no'
    luz = 'si' if luz == 'on' else 'no'
    drenaje = 'si' if drenaje == 'on' else 'no'

    vivienda = Vivienda(None, tipo, material, saneamiento, agua, luz, drenaje, tendencia, direccion, habitaciones, banios, localidades, municipio)
    vivienda.crear()
    return '''<script>
    alert("Vivienda creada correctamente");
    window.location.href="/viviendas"
    </script>'''

@app.route('/eliminar-vivienda', methods = ['post'])
def eliminarVivienda():
    id=request.form.get('id')
    Vivienda.eliminar(id)
    return '''<script>
    alert("Vivienda eliminada correctamente");
    window.location.href="/lista-viviendas"
    </script>'''

@app.route('/habitantes')
def habitantes():
    viviendas = Vivienda.listar()
    return render_template('habitantes.html', viviendas = viviendas)

@app.route('/lista-habitantes')
def listaHabitantes():
    id = request.args.get('id')
    habitantes = Habitante.listar(id)
    viviendas = Vivienda.listar()
    num = Vivienda.NumHabitantes()
    lista_combinada = zip(viviendas, num)
    return render_template('listaHabitantes.html', habitantes=habitantes, viviendas = lista_combinada)

@app.route('/guardar-habitante', methods=['POST'])
def guardarHabitante():
    nombre = request.form.get('nombre')
    edad = request.form.get('edad')
    sexo = request.form.get('sexo')
    edo_civil = request.form.get('edo_civil')
    nivel_educativo = request.form.get('nivel_educativo')
    ingresos = request.form.get('ingresos')
    nacionalidad = request.form.get('nacionalidad')
    vivienda_idvivienda = request.form.get('vivienda_idvivienda')

    # Realiza la validación y procesamiento de datos aquí si es necesario

    habitante = Habitante(
        None, nombre, edad, sexo, edo_civil, nivel_educativo, ingresos, nacionalidad, vivienda_idvivienda
    )
    
    habitante.crear()  # Asegúrate de tener el método crear() definido en la clase Habitante
    return '''<script>
    alert("Habitante creado correctamente");
    window.location.href="/habitantes"
    </script>'''

@app.route('/eliminar-habitante', methods=['POST'])
def eliminarHabitante():
    id = request.form.get('id')
    Habitante.eliminar(id)  # Asegúrate de tener el método eliminar() definido en la clase Habitante
    return '''<script>
    alert("Habitante eliminado correctamente");
    window.location.href="/lista-habitantes"
    </script>'''

@app.route('/dashboard')
def dashboard():
    data = Municipio.numHabitantes()
    df = pd.DataFrame(data)
    fig = px.bar(df, x='id', y='habitantes', text='municipio', title='numero de habitantes por municipio', custom_data=['municipio', 'habitantes'])

    # Convertir a JSON
    graph_json = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

    return render_template('dashboard.html', graph_json=graph_json)


@app.route('/dashboard/municipio')
def dashMunicipio():
    id = request.args.get('id')
    data = Localidad.NumHabitantes(id)
    print(data)
    df = pd.DataFrame(data)
    fig = px.bar(df, x='id', y='habitantes', text='localidad', title='numero de habitantes por localidad', custom_data=['localidad', 'habitantes'])

    # Convertir a JSON
    graph_json = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

    return render_template('dashboardLocalidad.html', graph_json=graph_json)

@app.route('/dashboard/localidad')
def dashLocalidad():
    id = request.args.get('id')
    data = Vivienda.NumHabitantesId(id)
    df = pd.DataFrame(data)
    fig = px.bar(df, x='id', y='habitantes', text='vivienda', title='numero de habitantes por vivienda', custom_data=['vivienda', 'habitantes'])

    # Convertir a JSON
    graph_json = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

    return render_template('dashboardVivienda.html', graph_json=graph_json)

@app.route('/admin')
def admin():
    return redirect(url_for('viviendas'))